﻿using System;
class Practice
{
    public static void Main()
    {
        Console.WriteLine("Hello,Enter your firstName");
        string firstName=Console.ReadLine
            ();
        Console.WriteLine("enter your lastName");
        string lastName = Console.ReadLine();

        Console.WriteLine("Hello {0}, {1}", firstName, lastName);


    }
    public static void Main2()
    {
        Console.WriteLine("I Love You");
        Main();
        Main2();
    }
}

