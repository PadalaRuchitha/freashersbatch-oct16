﻿using System;
    namespace Assignment1
{
    class Calculator
    {
        public static void Main()
        {
            Console.WriteLine("enter A value");
            int A=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter B value");
            int B=Convert.ToInt32(Console.ReadLine());

            int result = 0;

            Console.WriteLine("select your choice");
              Console.WriteLine("1.Addition\n2.Subtraction\n3.Multiplication\n4.Division");
            int choice=Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    result = A + B;
                    break;
                case 2:
                    result = A - B;
                    break;
                case 3:
                    result = A * B;
                    break;
                case 4:
                    result = A / B;
                    break;

                default:
                    
                    Console.WriteLine("Enter correct Choice");
                    break;
            }       
                    Console.WriteLine("Result={0}",result);
        }

    }

    

    }



