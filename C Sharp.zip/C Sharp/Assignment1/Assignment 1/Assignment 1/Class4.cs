﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Circle
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("enter the radius of the Circle");
            double circleRadius=Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter area of circle");
            double circlearea=Convert.ToDouble(Console.ReadLine());


            double Area = Math.PI * circleRadius * circleRadius;
            Console.WriteLine("Area of circle is: " +circlearea);




            double circumferenceOfCircle = 2 * Math.PI * circleRadius;
            Console.WriteLine("Circumference of circle is: " + circumferenceOfCircle);

        }

    }
}
