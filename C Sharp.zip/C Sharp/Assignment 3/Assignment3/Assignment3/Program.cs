﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LitwareLib
{
    public class Employee
    {
        int EmpNo;
        string EmpName;
        double Salary;
        double HRA;
        double TA;
        double DA;
        double PF;
        double TDS;
        double NetSalary;
        double GrossSalary;

        public double _GrossSalary
        {
            get
            {
                return GrossSalary;
            }
            set
            {
                GrossSalary = value;
            }
        }

        public double _Salary
        {
            get
            {
                return Salary;
            }
            set
            {
                Salary = value;
            }
        }

        public double _PF
        {
            get
            {
                return PF;
            }
            set
            {
                PF = value;
            }
        }

        public double _TDS
        {
            get
            {
                return TDS;
            }
            set
            {
                TDS = value;
            }
        }

        public double _NetSalary
        {
            get
            {
                return NetSalary;
            }
            set
            {
                NetSalary = value;
            }
        }


        public void setEmpDetails(int EmpNo, string EmpName, double Salary)
        {
            this.EmpNo = EmpNo;
            this.EmpName = EmpName;
            this.Salary = Salary;
        }
        public void getEmpDetails()
        {
            Console.WriteLine("Employee Number is: " + this.EmpNo);
            Console.WriteLine("Employee Name is: " + this.EmpName);
            Console.WriteLine("Employee Salary is: " + this.Salary);
        }


        public double setHRA(double HRA)
        {

            if (Salary > 0 & Salary < 5000)
            {
                HRA = (10 * Salary) / 100;
                return this.HRA = HRA;
            }
            else if (Salary > 5000 & Salary < 10000)
            {
                HRA = (15 * Salary) / 100;
                return this.HRA = HRA;
            }
            else if (Salary > 10000 & Salary < 15000)
            {
                HRA = (20 * Salary) / 100;
                return this.HRA = HRA;
            }
            else if (Salary > 15000 & Salary < 20000)
            {
                HRA = (25 * Salary) / 100;
                return this.HRA = HRA;
            }
            else
            {
                HRA = (30 * Salary) / 100;
                return this.HRA = HRA;
            }

        }

        public double setTA(double TA)
        {
            this.TA = TA;

            if (Salary < 5000)
            {
                TA = (5 * Salary) / 100;
                return this.TA = TA;
            }
            else if (Salary < 10000)
            {
                TA = (10 * Salary) / 100;
                return this.TA = TA;
            }
            else if (Salary < 15000)
            {
                TA = (15 * Salary) / 100;
                return this.TA = TA;
            }
            else if (Salary < 20000)
            {
                TA = (20 * Salary) / 100;
                return this.TA = TA;
            }
            else
            {
                TA = (25 * Salary) / 100;
                return this.TA = TA;
            }
        }

        public double setDA(double DA)
        {
            this.DA = DA;

            if (Salary < 5000)
            {
                DA = (15 * Salary) / 100;
                return this.DA = DA;
            }
            else if (Salary < 10000)
            {
                DA = (20 * Salary) / 100;
                return this.DA = DA;
            }
            else if (Salary < 15000)
            {
                DA = (25 * Salary) / 100;
                return this.DA = DA;
            }
            else if (Salary < 20000)
            {
                DA = (30 * Salary) / 100;
                return this.DA = DA;
            }
            else
            {
                DA = (35 * Salary) / 100;
                return this.DA = DA;
            }
        }

        public double getGrossSalary(double Salary, double HRA, double TA, double DA)
        {
            this.GrossSalary = Salary + HRA + TA + DA;
            return this.GrossSalary;
        }

        public virtual void CalculateSalary(double GrossSalary)
        {
            this.PF = (10 * GrossSalary) / 100;
            this.TDS = (18 * GrossSalary) / 100;
            this.NetSalary = GrossSalary - (this.PF + this.TDS);
        }



        public void showSalary()
        {
            Console.WriteLine("Your PF is: {0}", this.PF);
            Console.WriteLine("Your TDS is: {0}", this.TDS);
            Console.WriteLine("Your NetSalary is: {0}", this.NetSalary);
        }

    }

    //Manager

    public class Manager : Employee
    {
        double Petrol_Allowance;
        double Food_Allowance;
        double Other_Allowance;

        public double setPetrol(double _Salary)
        {
            this.Petrol_Allowance = (8 * _Salary) / 100;
            return this.Petrol_Allowance;
        }

        public double setFood(double _Salary)
        {

            this.Food_Allowance = (13 * _Salary) / 100;
            return this.Food_Allowance;
        }

        public double setOther(double _Salary)
        {
            this.Other_Allowance = (3 * _Salary) / 100;
            return this.Other_Allowance;
        }


        public virtual double setAllowance(double Petrol_Allowance, double Food_Allowance, double Other_Allowance)
        {
            this._GrossSalary = Petrol_Allowance + Food_Allowance + Other_Allowance;
            return this._GrossSalary;
        }

        public override void CalculateSalary(double GrossSalary)
        {

            this._PF = (10 * GrossSalary) / 100;
            this._TDS = (18 * _GrossSalary) / 100;
            this._NetSalary = _GrossSalary - (this._PF + this._TDS);

        }

        public void showSalary()
        {
            Console.WriteLine("Your PF is: {0}", this._PF);
            Console.WriteLine("Your TDS is: {0}", this._TDS);
            Console.WriteLine("Your NetSalary is: {0}", this._NetSalary);
        }
    }

    //MarketingExecutive
    public class MarketingExecutive : Manager
    {
        private double Kilometer_travel;
        private double Tour_Allowance = 5;
        private double Telephone_Allowance = 1000;

        public double setTravel(double Kilometer_travel)
        {
            return this.Kilometer_travel = Kilometer_travel;
        }

        public void getTravel()
        {
            Console.WriteLine("You traveled for : " + Kilometer_travel + " kms");
        }

        public double getTour(double Tour_Allowance)
        {
            this.Tour_Allowance = 5 * this.Kilometer_travel;
            return this.Tour_Allowance;
        }

        public double setTour(double Tour_Allowance)
        {
            this.Tour_Allowance = 5 * this.Kilometer_travel;
            return this.Tour_Allowance;
        }

        public void getTour()
        {
            Console.WriteLine("Tour Allowance per km is: Rs.{0}", this.Tour_Allowance);
        }

        public double setTelephone()
        {
            return this.Telephone_Allowance = 1000;

        }

        public override double setAllowance(double Kilometer_travel, double Tour_Allowance, double Telephone_Allowance)
        {
            this._GrossSalary = Tour_Allowance + Telephone_Allowance;
            return this._GrossSalary;
        }

        public override void CalculateSalary(double GrossSalary)
        {

            this._PF = (10 * GrossSalary) / 100;
            this._TDS = (18 * GrossSalary) / 100;
            this._NetSalary = GrossSalary - (this._PF + this._TDS);

        }

        public void showSalary()
        {
            Console.WriteLine("Your PF is: {0}", this._PF);
            Console.WriteLine("Your TDS is: {0}", this._TDS);
            Console.WriteLine("Your NetSalary is: {0}", this._NetSalary);
        }
    }


}


Program.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LitwareLib;

namespace Assignment2
{
    public class Program
    {

        static void Main(string[] args)
        {

            Employee obj = new Employee();
            Console.WriteLine("----------Accepting Employee Details----------");

            Console.WriteLine("Enter Employee Number:");
            int no = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Employee Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Employee Salary:");
            double salary = double.Parse(Console.ReadLine());

            obj.setEmpDetails(no, name, salary);

            Console.WriteLine("\n----------Displaying Employee Details----------");

            obj.getEmpDetails();

            double resultHRA = obj.setHRA(salary);
            Console.WriteLine("Your HRA is: {0}", resultHRA);

            double resultTA = obj.setTA(salary);
            Console.WriteLine("Your TA is: {0}", resultTA);

            double resultDA = obj.setDA(salary);
            Console.WriteLine("Your DA is: {0}", resultDA);

            double grossSalary = obj.getGrossSalary(salary, resultHRA, resultDA, resultTA);
            Console.WriteLine("Your Gross Salary is: {0}", grossSalary);

            obj.CalculateSalary(grossSalary);
            obj.showSalary();


            Console.WriteLine("\n----------Displaying Manager Details----------");

            Manager obj1 = new Manager();

            double petrol = obj1.setPetrol(salary);
            Console.WriteLine("Petrol Allowance: {0}", petrol);

            double food = obj1.setFood(salary);
            Console.WriteLine("Food Allowance: {0}", food);

            double other = obj1.setOther(salary);
            Console.WriteLine("Other Allowance: {0}", other);

            double gross1 = obj1.getGrossSalary(salary, resultHRA, resultDA, resultTA);
            double gross2 = obj1.setAllowance(petrol, food, other);
            double result_gross = gross1 + gross2;
            Console.WriteLine("Gross Salary of Manager on adding the Allowances is: {0}", result_gross);

            obj.CalculateSalary(result_gross);
            obj.showSalary();

            Console.WriteLine("\n---------Displaying Marketing Executive----------");

            MarketingExecutive obj2 = new MarketingExecutive();

            Console.WriteLine("Enter Kilometer Travel: ");
            double travel = double.Parse(Console.ReadLine());
            obj2.setTravel(travel);
            obj2.getTravel();

            double tour = obj2.setTour(travel);
            obj2.getTour();

            double tele = obj2.setTelephone();
            Console.WriteLine("Telephone Allowances are: Rs.{0}", tele);

            double gross3 = obj2.setAllowance(travel, tour, tele);
            double result_gross_final = result_gross + gross3;
            Console.WriteLine("Gross Salary of Marketing Executive on adding the Allowances is: {0}", result_gross_final);

            obj2.CalculateSalary(result_gross_final);
            obj2.showSalary();

            Console.ReadLine();
        }
    }
}
